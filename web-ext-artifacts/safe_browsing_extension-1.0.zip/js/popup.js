// popup.js
document.getElementById('clickme').addEventListener('click', () => {
    alert('Button clicked!');
});
